from django.shortcuts import render
from django.http import HttpResponse
from django.utils.crypto import get_random_string

from django.views.decorators.csrf import csrf_exempt
from . import models
from django import template
register = template.Library()

def sendInterviewLink(candidateId):
    row = models.FeedbackToCandidate(linkId=get_random_string(length=30), candidateId=candidateId)
    row.save()
    #url = settings.SLICKHIRE_HOST_URL + "/feedback?linkId=" + row.linkId
    url = "http://localhost:8000/polls/feedback?linkId=" + row.linkId
    print("url is", url)
    return url

def index(request) :
    feedback = models.Persons.objects.all()
    feedback.delete()
            
    row = models.Persons(candidateId="abcdef")
    sendInterviewLink("abcdef")
    row.save()
    return render(request, 'index.html')


# per candidate feedback
def getFeedback(request):
    linkId = request.GET["linkId"]
    print(linkId)
    data = models.FeedbackToCandidate.objects.get(linkId__exact=linkId)
    candidate = models.Persons.objects.get(candidateId__exact=data.candidateId)

    values_list = []
    last_value = ""
    print("get feedback values_string", candidate.values_string, candidate.feedback_string, candidate.values_string == "", "xxxxxx") 
    if candidate.values_string != "":
        for x in candidate.values_string.split('$'):
            print("in loop")
            values_list.append(x)
            print(x)
        if values_list:
            values_list.pop()

    feedback_list = []
    feedback_str = candidate.feedback_string
    if candidate.feedback_string == "":
        feedback = models.Feedback.objects.filter()[:1].get()
        feedback_str = feedback.feedback_string
        
    for x in feedback_str.split('$'):
        feedback_list.append(x)
        print(x)
    feedback_list.pop()


    print("candidate is", data.candidateId)
    return render(request,"feedback.html", { 'values_list' : values_list, 'length': len(feedback_list), 'feedback_str': feedback_str, 'feedback_string': feedback_list, 'linkId' : linkId})

    
# settings feedback    
@csrf_exempt
def saveFeedback(request) :
    if request.method == 'POST':
        if 'feedback_string' in request.POST:
            feedback = models.Feedback.objects.all()
            feedback.delete()
            print(request.POST['feedback_string'])
            feedback = models.Feedback(feedback_string=request.POST['feedback_string'])
            feedback.save()

            return HttpResponse("Saved Successfully")
        else:
            linkId = request.POST['linkId']

            data = models.FeedbackToCandidate.objects.get(linkId__exact=linkId)
            candidate = models.Persons.objects.get(candidateId__exact=data.candidateId)
            candidate.feedback_string = request.POST["fields_string"]
            candidate.values_string = request.POST["values_string"]
            print("save feedback values_string", candidate.values_string) 
            candidate.save()
            return HttpResponse("Saved Successfully")
        
    if request.method == 'GET':
        feedback = models.Feedback.objects.filter()[:1].get()
        feedback_list = []
        last = ""
        for x in feedback.feedback_string.split('$'):
            feedback_list.append(x)
            print(x)
        feedback_list.pop()
        last = feedback_list.pop()
        print(feedback.feedback_string)
        return render(request,"index.html",{'feedback_string': feedback_list, 'last': last})
# Create your views here.
