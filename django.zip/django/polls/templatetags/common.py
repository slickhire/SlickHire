from django import template
register = template.Library()

@register.simple_tag
def lookup(d, key, length, outerIter):
    print("index is ", key, length, outerIter)
    key = int(key) + (int(length)*int(outerIter)) + int(outerIter)
    print("index is ", key)
    if len(d) <= key:
        return ""
    return d[key]

@register.filter
def add(key, num):
    print("add is ", key, num)
    key = key + num
    return ""