from django.db import models

# Create your models here.
class Feedback(models.Model):
    feedback_string = models.CharField(max_length=30)
    
    
class FeedbackToCandidate(models.Model):
    linkId = models.CharField(max_length=31, primary_key=True)
    candidateId = models.CharField(max_length=500)

class Persons(models.Model):
    candidateId = models.CharField(max_length=50)
    feedback_string = models.CharField(max_length=500)
    values_string = models.CharField(max_length=500)
